using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using Thirdweb;

public class ConnectWallet : MonoBehaviour
{
    public GameObject claimPrompt;
    public GameObject connectPrompt;
    public PlayerInput move;
    public GameObject character;

    public GameObject connected;
    string address;
    Contract contract;
    public GameObject LoadingState;

    void Start()
    {
        claimPrompt.SetActive(false);
        connectPrompt.SetActive(true);
        move.enabled = false;
        character.SetActive(false);

        connected.SetActive(false);
        LoadingState.SetActive(false);
        contract = ThirdwebManager.Instance.SDK.GetContract("0xd6ea454e9c1bCDd142DDBcB2b53D96A7a66343B2");
    }

    public void connectwallet()
    {
        //connectPrompt.SetActive(false);
        //move.enabled = true;
        //character.SetActive(true);
        connected.SetActive(true);
        WalletNFTBalance();
    }

    async public void WalletNFTBalance()
    {
        var address = await ThirdwebManager.Instance.SDK.wallet.GetAddress();
        var characterBalance = await contract.ERC1155.BalanceOf(address, "0");
        var characterBalanceInt = int.Parse(characterBalance);
        if(characterBalanceInt > 0)
        {
            connectPrompt.SetActive(false);
            connected.SetActive(false);
            move.enabled = true;
            character.SetActive(true);
        }
        else
        {
            connectPrompt.SetActive(false);
            LoadingState.SetActive(true);
            connected.SetActive(false);
        }
    }

    public void showconnectPrompt()
    {
        connectPrompt.SetActive(true);
        move.enabled = false;
        character.SetActive(false);
    }
}
