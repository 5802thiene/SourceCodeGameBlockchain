using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GemContact : MonoBehaviour
{
    public GameObject claimPrompt;

    [SerializeField] private TMPro.TextMeshProUGUI ScoreText;
    public int countScore = 0;
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.CompareTag("Gem"))
        {
            Destroy(other.gameObject);
            countScore++;
            ScoreText.text ="Gem: " + countScore.ToString();
        }

    }

    void Update()
    {
        if(countScore == 2)
        {
            claimPrompt.SetActive(true);
        }
    }

}
