using UnityEngine;

public class Camera : MonoBehaviour
{
    public Transform target; // Reference to the player's Transform component
    public Vector3 offset; // Offset to adjust the camera position relative to the player

    void LateUpdate()
    {
        if (target == null)
        {
            Debug.LogWarning("Target (player) not assigned to the CameraFollow2D script!");
            return;
        }

        Vector3 desiredPosition = target.position + offset;
        transform.position = new Vector3(desiredPosition.x, desiredPosition.y, transform.position.z);
    }
}