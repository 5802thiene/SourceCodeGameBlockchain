namespace WalletConnect
{
    public enum WCStorageType
    {
        None,
        Disk,
        // PlayerPrefs
    }
}