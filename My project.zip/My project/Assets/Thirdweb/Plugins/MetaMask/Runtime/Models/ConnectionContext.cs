namespace MetaMask.Models
{
    public enum ConnectionContext
    {
        Deeplink,
        Uri,
    }
}