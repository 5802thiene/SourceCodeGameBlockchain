namespace MetaMask
{
    public interface IMetaMaskEvents
    {
        public IMetaMaskEventsHandler Events { get; }
    }
}