namespace evm.net.Models
{
    public interface IContract
    {
        string Address { get; }
    }
}