namespace evm.net.Models.ABI
{
    public class ABIError : ABIDef
    {
    }
}