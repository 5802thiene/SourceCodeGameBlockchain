namespace evm.net.Models.ABI
{
    public enum ABIStateMutability
    {
        Pure,
        View,
        Nonpayable,
        Payable,
    }
}