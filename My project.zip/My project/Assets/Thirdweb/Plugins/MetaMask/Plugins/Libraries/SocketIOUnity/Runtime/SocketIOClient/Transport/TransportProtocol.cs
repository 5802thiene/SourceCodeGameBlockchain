﻿namespace MetaMask.SocketIOClient.Transport
{
    public enum TransportProtocol
    {
        Polling,
        WebSocket
    }
}
