using System.Collections.Generic;

namespace evm.net.Models.ABI
{
    public class ContractABI : List<ABIDef>
    {
        
    }
}