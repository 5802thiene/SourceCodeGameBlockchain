﻿namespace evm.net.Models
{
    public interface IConvertableType
    {
        object Convert();
    }
}