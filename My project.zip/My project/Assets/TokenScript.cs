
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Thirdweb;
using UnityEngine.SceneManagement;

public class TokenScript : MonoBehaviour
{
    public GemContact gemScript;

    public GameObject HasNotClaimedState;
    public GameObject ClaimingState;
    public GameObject HasClaimedState;

    [SerializeField] public TMPro.TextMeshProUGUI gemEarnText;

    [SerializeField] private TMPro.TextMeshProUGUI tokenBallanceText;
    private const string DROP_ERC20_CONTRACT = "0xc4372a95396d578d7c8d898aB4c3f9079CD34D7e";


    private int gemToClaim;

    void Start()
    {
        HasNotClaimedState.SetActive(true);
        ClaimingState.SetActive(false);
        HasClaimedState.SetActive(false);
    }

    private void Update()
    {
        gemEarnText.text = "Game Earned: " + gemScript.countScore.ToString();
        gemToClaim = gemScript.countScore;
    }

    public async void GetTokenBallance()
    {
        try
        {
            var address = await ThirdwebManager.Instance.SDK.wallet.GetAddress();
            Contract contract = ThirdwebManager.Instance.SDK.GetContract(DROP_ERC20_CONTRACT);
            var data = await contract.ERC20.BalanceOf(address);
            tokenBallanceText.text = "Gem: " + data.displayValue;
        }
        catch (System.Exception)
        {
            Debug.Log("Error getting token balance");
        }
    }

    public void ResetBalance()
    {
        tokenBallanceText.text = "Gem: 0";
    }

    public async void MintERC20() 
    { 
        try
        {
            Debug.Log("Minting ERC20");
            Contract contract = ThirdwebManager.Instance.SDK.GetContract(DROP_ERC20_CONTRACT);
            HasNotClaimedState.SetActive(false);
            ClaimingState.SetActive(true);
            var results = await contract.ERC20.Claim(gemToClaim.ToString());
            Debug.Log("ERC20 minted");
            GetTokenBallance();
            ClaimingState.SetActive(false);
            HasClaimedState.SetActive(true);
        }
        catch (System.Exception)
        {
            Debug.Log("Error minting ERC20");
        }

    }

    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

}
